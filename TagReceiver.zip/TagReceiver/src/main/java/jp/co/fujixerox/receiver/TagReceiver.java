/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.fujixerox.receiver;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.springframework.stereotype.Component;

/**
 *
 * @author cnxulj
 */
@Component
@Path("/tag-receiver")
public class TagReceiver{

    @PUT
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/event/{eventID}")
    public Response onPutEvent(
            @PathParam("eventID") String eventID,
            @HeaderParam("Authorization") String authorization,
            String event) throws Exception {
        System.out.println("-----PUT---------putEvent Start----PUT----------");
        System.out.println(eventID);
        System.out.println("Authorization :" + authorization);
        System.out.println(event);
        String data = "Event Tag Saved :" + event;
        System.out.println("----PUT-------putEvent End------PUT---------");

        return Response.status(200).entity(data).build();
    }

    @PUT
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/project/{projectID}")
    public Response onPutProject(
            @PathParam("projectID") String projectID,
            @HeaderParam("Authorization") String authorization,
            String project) throws Exception {
        System.out.println("----PUT--------putProject Start----PUT----------");
        System.out.println(projectID);
        System.out.println("Authorization :" + authorization);
        System.out.println(project);
        String data = "project Tag Saved :" + project;
        System.out.println("----PUT--------putProject End------PUT--------");

        return Response.status(200).entity(data).build();
    }

    @PUT
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/document/{documentID}")
    public Response onPutDocument(
            @PathParam("documentID") String documentID,
            @HeaderParam("Authorization") String authorization,
            String document) throws Exception {
        System.out.println("-----PUT-------PutDocument Start----PUT---------");
        System.out.println(documentID);
        System.out.println("Authorization :" + authorization);
        System.out.println(document);
        String data = "document Tag Saved :" + document;
        System.out.println("-----PUT--------PutDocument End------PUT----------");

        return Response.status(200).entity(data).build();
    }

    @PUT
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/comment/{commentID}")
    public Response onPutComment(
            @PathParam("commentID") String commentID,
            @HeaderParam("Authorization") String authorization,
            String comment) throws Exception {
        System.out.println("-----PUT--------PutComment Start----PUT--------");
        System.out.println(commentID);
        System.out.println("Authorization :" + authorization);
        System.out.println(comment);
        String data = "comment Tag Saved :" + comment;
        System.out.println("-----PUT--------PutComment End------PUT------");

        return Response.status(200).entity(data).build();
    }

}
