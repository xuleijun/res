package jp.co.fujixerox.receiver;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.springframework.stereotype.Component;
import org.glassfish.jersey.server.ResourceConfig;

/**
 *
 * @author cnluor
 */
@Component
public class JerseyConfig extends ResourceConfig {
    
    public JerseyConfig() {
        
        // filter類はここにいれていく
        //register(JacksonFeature.class);
        register(TagReceiver.class);
    }

}
