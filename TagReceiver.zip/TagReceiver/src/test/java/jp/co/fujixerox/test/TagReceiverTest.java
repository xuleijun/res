/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.fujixerox.test;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jp.co.fujixerox.receiver.TagRecApplication;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *
 * @author cnxulj
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TagRecApplication.class)
@WebIntegrationTest(randomPort = true)
public class TagReceiverTest {

    @Value("${local.server.port}")
    private int port;

    @Test
    public final void onPutEventTestOK() {
        System.out.println("onPutEventTestOK start");
        String eventObject = "{'id':'1','title':'XXX.レビュー'}";

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:" + this.port + "/tag-receiver/event/1");

        //Post Request from Jersey Client
        Response response = target.request()
                .header("Authorization", "Basic xxxxxxxposteventxxxxxx")
                .header("Content-Type", "application/json;charset=UTF-8")
                .buildPut(Entity.entity(eventObject, MediaType.APPLICATION_JSON)).invoke();
        assertEquals(200, response.getStatus());
        System.out.println("onPutEventTestOK end");
    }

    @Test
    public final void onPutProjectTestOK() {
        System.out.println("onPutProjectTestOK start");
        String eventObject = "{'id':'2','title':'XXX.レビュー'}";

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:" + this.port + "/tag-receiver/project/2");

        //Post Request from Jersey Client
        Response response = target.request()
                .header("Authorization", "Basic xxxxxxxpostprojectxxxxxx")
                .header("Content-Type", "application/json;charset=UTF-8")
                .buildPut(Entity.entity(eventObject, MediaType.APPLICATION_JSON)).invoke();
        assertEquals(200, response.getStatus());
        System.out.println("onPutProjectTestOK end");
    }

    @Test
    public final void onPutDocumentTestOK() {
        System.out.println("onPutDocumentTestOK start");
        String eventObject = "{'id':'3','title':'XXX.レビュー'}";

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:" + this.port + "/tag-receiver/document/3");

        //Post Request from Jersey Client
        Response response = target.request()
                .header("Authorization", "Basic xxxxxxxpostdocumentxxxxxx")
                .header("Content-Type", "application/json;charset=UTF-8")
                .buildPut(Entity.entity(eventObject, MediaType.APPLICATION_JSON)).invoke();
        assertEquals(200, response.getStatus());
        System.out.println("onPutDocumentTestOK end");
    }

    @Test
    public final void onPutCommentTestOK() {
        System.out.println("onPutCommentTestOK start");
        String eventObject = "{'id':'4','title':'XXX.レビュー'}";

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:" + this.port + "/tag-receiver/comment/4");

        //Post Request from Jersey Client
        Response response = target.request()
                .header("Authorization", "Basic xxxxxxxpostcommentxxxxxx")
                .header("Content-Type", "application/json;charset=UTF-8")
                .buildPut(Entity.entity(eventObject, MediaType.APPLICATION_JSON)).invoke();
        assertEquals(200, response.getStatus());
        System.out.println("onPutCommentTestOK end");
    }
}
