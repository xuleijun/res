/*
 * To change this license header, choose License Headers in InProject Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.fujixerox.taggen;

import java.util.HashSet;
import java.util.Iterator;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import jp.co.fujixerox.dcpf.facets_indexer.bean.Term;
import jp.co.fujixerox.dcpf.facets_indexer.utils.Category;
import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author cnxulj
 */
@Component
@Path("/tag-generator")
public class TagGeneratorPost {

	@Autowired
	private Category cat;

	@Autowired
	private Term term;

	@Value("${receiverBaseUrl}")
	private String receiverBaseUrl;

	private static final Logger log = LoggerFactory.getLogger(TagGeneratorPost.class);

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response onPost(@HeaderParam("Authorization") String authorization, String json) throws Exception {
		String jsonId = null;
		String jsonType = null;
		JSONObject dataObject = null;
		try {
			log.debug("*******Post Handler Start*********");
			
			if (isNullOrEmpty(authorization) || isNullOrEmpty(json)) {
				log.error("TagGeneratorPost.onPost().authorization :{}", authorization);
				log.error("TagGeneratorPost.onPost().json :{}", json);
				return Response.status(Response.Status.BAD_REQUEST).entity("Bad Request").build();
			}

			JSONObject rootObject = JSONObject.fromObject(json);
			jsonId = rootObject.getString("id");
			jsonType = rootObject.getString("type");
			dataObject = rootObject.getJSONObject("data");

			JSONArray jsonData = null;

			if (jsonType.equals("event")) {
				if(noContainsKeyOrNullEmpty(dataObject, "title")){
					throw new JSONException("[title]isn't contained in [dataObject]or is null");
				}
				jsonData = onPostEvent(dataObject);
			} else if (jsonType.equals("project")) {
				if(noContainsKeyOrNullEmpty(dataObject, "title")){
					throw new JSONException("[title]isn't contained in [dataObject]or is null");
				}
				jsonData = onPostProject(dataObject);
			} else if (jsonType.equals("document")) {
				if(noContainsKeyOrNullEmpty(dataObject, "title")||noContainsKeyOrNullEmpty(dataObject, "fulltext")){
					throw new JSONException("[title]or[fulltext]isn't contained in [dataObject]or is null");
				}
				jsonData = onPostDocument(dataObject);
			} else if (jsonType.equals("comment")) {
				if(noContainsKeyOrNullEmpty(dataObject, "body")){
					throw new JSONException("[body]isn't contained in [dataObject]or is null");
				}
				jsonData = onPostComment(dataObject);
			} else {
				log.error("TagGeneratorPost.onPost().jsonType :{}", jsonType);
				return Response.status(Response.Status.BAD_REQUEST).entity("Bad Request").build();
			}

			log.info("TagGeneratorPost.onPost().jsonData :{}", jsonData);
			if (jsonData == null) {
				log.error("TagGeneratorPost.onPost().jsonData :{}", jsonData);
				return Response.status(Response.Status.BAD_REQUEST).entity("Bad Request").build();
			}

			// 外部apiへの送信する結果を判断する
			boolean result = putRequest(jsonType, jsonId, jsonData, authorization);
			if (!result) {
				log.error("TagGeneratorPost.onPost().jsonType :{}", jsonType);
				log.error("TagGeneratorPost.onPost().jsonId :{}", jsonId);
				log.error("TagGeneratorPost.onPost().jsonData :{}", jsonData);
				log.error("TagGeneratorPost.onPost().authorization :{}", authorization);
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Internal Server Error").build();
			}

			log.debug("*******Post Handler End*******");
			return Response.status(Response.Status.OK).build();
			
		} catch (JSONException je) {
			log.error("TagGeneratorPost.onPost().jsonId :{}", jsonId);
		    log.error("TagGeneratorPost.onPost().jsonType :{}", jsonType);
		    log.error("TagGeneratorPost.onPost().dataObject :{}", dataObject);
		    return Response.status(Response.Status.BAD_REQUEST).entity("Bad Request").build();
		} catch (Exception e) {
			log.error("TagGeneratorPost.onPost().Exception :{}", e);
		    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Internal Server Error").build();
		}
	}
	
	public JSONArray onPostEvent(JSONObject eventDataObject) {
		log.debug("*******onPostEvent Start*********");
		
		String eventTitle = eventDataObject.getString("title");
		String typResult = cat.getEventType(eventTitle);
		// getEventTypeを呼び出したString型の結果がnullか空stringかを判断する
		if (isNullOrEmpty(typResult)) {
			log.error("TagGeneratorPost.onPostEvent().typResult :{}", typResult);
			return null;
		}

		HashSet<String> extResult = term.extractTerm(eventTitle);
		JSONArray jsonData = new JSONArray();
		addKeyPair(jsonData, "eventtype", typResult);
		addKeywordValue(extResult,jsonData);

		log.debug("*******onPostEvent End*******");
		return jsonData;
	}

	public JSONArray onPostProject(JSONObject projectDataObject) {
		log.debug("*******onPostProject Start*********");
		
		String projectTitle = projectDataObject.getString("title");
		String typResult = cat.getProjectType(projectTitle);
		// getProjectTypeを呼び出したString型の結果がnullか空stringかを判断する
		if (isNullOrEmpty(typResult)) {
			log.error("TagGeneratorPost.onPostProject().typResult :{}", typResult);
			return null;
		}

		HashSet<String> extResult = term.extractTerm(projectTitle);
		JSONArray jsonData = new JSONArray();
		addKeyPair(jsonData, "projecttype", typResult);
		addKeywordValue(extResult,jsonData);

		log.debug("*******onPostProject End*******");
		return jsonData;
	}

	public JSONArray onPostDocument(JSONObject documentDataObject) {
		log.debug("*******onPostDocument Start*********");
		
		String documentTitle = documentDataObject.getString("title");
		String documentFulltext = documentDataObject.getString("fulltext");
		String contentTypeResult = cat.getContentType(documentTitle);
		String fileTypeResult = cat.getFileType(documentTitle);
		// getContentTypeとgetFileTypeを呼び出したString型の結果がnullか空stringかを判断する
		if (isNullOrEmpty(contentTypeResult) || isNullOrEmpty(fileTypeResult)) {
			log.error("TagGeneratorPost.onPostDocument().contentTypeResult :{}", contentTypeResult);
			log.error("TagGeneratorPost.onPostDocument().fileTypeResult :{}", fileTypeResult);
			return null;
		}

		HashSet<String> extTitleResult = term.extractTerm(documentTitle);
		HashSet<String> extFulltextResult = term.extractTerm(documentFulltext);
		JSONArray jsonData = new JSONArray();
		addKeyPair(jsonData, "contenttype", contentTypeResult);
		addKeyPair(jsonData, "filetype", fileTypeResult);
		addKeywordValue(extTitleResult,jsonData);
		addKeywordValue(extFulltextResult,jsonData);

		log.debug("*******onPostDocument End*******");
		return jsonData;
	}

	public JSONArray onPostComment(JSONObject commentDataObject) {
		log.debug("*******onPostComment Start*********");
		
		String commentBody = commentDataObject.getString("body");
		HashSet<String> extResult = term.extractTerm(commentBody);
		JSONArray jsonData = new JSONArray();
		addKeywordValue(extResult,jsonData);

		log.debug("*******onPostComment End*******");
		return jsonData;
	}

	public boolean putRequest(String type, String id, Object data, String authorization) throws Exception {
		boolean result = false;
		try {
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(receiverBaseUrl).path(type + "/" + id);

			// PUT Request from Jersey Client
			Response response = target.request().header("Authorization", authorization)
					.header("Content-Type", "application/json;charset=UTF-8")
					.buildPut(Entity.entity(data, MediaType.APPLICATION_JSON)).invoke();

			log.debug(response.toString());

			if (response.getStatus() == Response.Status.OK.getStatusCode()) {
				result = true;
			}
			log.info("PUT :{} :{} {}", type, id, response.getStatus());
			log.info("PUT :{} :{} :{} {}", type, id, data, response.getStatus());

			response.close();
		} catch (Exception e) {
			log.error("TagGeneratorPost.putRequest().Exception :{}", e);
		}
		return result;
	}

	private void addKeyPair(JSONArray target, String name, String value) {
		JSONObject kpObject = new JSONObject();
		kpObject.accumulate("name", name);
		kpObject.accumulate("value", value);
		target.add(kpObject);
	}

	private void addKeywordValue(HashSet<String> extractTermResult, JSONArray jsonData){
		Iterator<String> iterator = extractTermResult.iterator();
		while (iterator.hasNext()) {
			addKeyPair(jsonData, "keyword", iterator.next());
		}
	}
	
	private boolean isNullOrEmpty(String value) {
		return (value == null || value.isEmpty());
	}
	
	private boolean noContainsKeyOrNullEmpty(JSONObject dataObject, String keyValue) {
		boolean rst = false;
		if(!dataObject.containsKey(keyValue)||isNullOrEmpty(dataObject.getString(keyValue))){
			log.error("TagGeneratorPost.onPost().dataObject :{}", dataObject);
			rst = true;
		}
		return rst;
	}
}
