package jp.co.fujixerox.test;

import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import mockit.Mock;
import mockit.MockUp;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import jp.co.fujixerox.taggen.TagGenApplication;
import jp.co.fujixerox.taggen.TagGeneratorPost;
import jp.co.fujixerox.dcpf.facets_indexer.utils.Category;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TagGenApplication.class)
public class TagGeneratorMockTest {

	@Autowired
	private TagGeneratorPost tagGeneratorPost;

	/**
	 * event type onPost.
	 */
	@Test
	public final void onPostOK1() {
		System.out.println("onPostOK start");
		try {
			String json = "{'id':'1','type':'event','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.OK.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostOK end");
		}
	}

	/**
	 * project type onPost.
	 */
	@Test
	public final void onPostOK2() {
		System.out.println("onPostOK2 start");
		try {
			String json = "{'id':'1','type':'project','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostProjectxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.OK.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostOK2 end");
		}
	}

	/**
	 * document type onPost.
	 */
	@Test
	public final void onPostOK3() {
		System.out.println("onPostOK3 start");
		try {
			String json = "{'id':'3','type':'document','data':{'title':'XXX.定例会','fulltext':'Sheet1 吾輩は猫背である。。。 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890 １２３４５６７８９０ ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ ﾜｶﾞﾊｲﾊﾈｺｾﾞﾃﾞｱﾙ｡｡｡ Sheet2 Sheet3 '}}";
			String authorization = "Basic xxxxxxxpostDocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.OK.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostOK3 end");
		}
	}

	/**
	 * comment type onPost.
	 */
	@Test
	public final void onPostOK4() {
		System.out.println("onPostOK4 start");
		try {
			String json = "{'id':'4','type':'comment','data':{'body':'Sheet1 吾輩は猫背である。。。 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890 １２３４５６７８９０ ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ ﾜｶﾞﾊｲﾊﾈｺｾﾞﾃﾞｱﾙ｡｡｡ Sheet2 Sheet3 '}}";
			String authorization = "Basic xxxxxxxpostCommentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.OK.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostOK4 end");
		}
	}

	/**
	 * onPost authorization null.
	 */
	@Test
	public final void onPostNG1() {
		System.out.println("onPostNG1 start");
		try {
			String json = "{'id':'1','type':'event','data':{'title':'XXX.レビュー'}}";
			String authorization = null;
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG1 end");
		}
	}

	/**
	 * onPost json null.
	 */
	@Test
	public final void onPostNG2() {
		System.out.println("onPostNG2 start");
		try {
			String json = null;
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG2 end");
		}
	}

	/**
	 * onPost json no id.
	 */
	@Test
	public final void onPostNG3() {
		System.out.println("onPostNG3 start");
		try {
			String json = "{'type':'event','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG3 end");
		}
	}

	/**
	 * onPost json no type.
	 */
	@Test
	public final void onPostNG4() {
		System.out.println("onPostNG4 start");
		try {
			String json = "{'id':'1','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG4 end");
		}
	}

	/**
	 * onPost json no data.
	 */
	@Test
	public final void onPostNG5() {
		System.out.println("onPostNG5 start");
		try {
			String json = "{'id':'1','type':'event'}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG5 end");
		}
	}

	/**
	 * onPost json id no value.
	 */
	@Test
	public final void onPostNG6() {
		System.out.println("onPostNG6 start");
		try {
			String json = "{'id':'','type':'event','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG6 end");
		}
	}

	/**
	 * onPost json type no value.
	 */
	@Test
	public final void onPostNG7() {
		System.out.println("onPostNG7 start");
		try {
			String json = "{'id':'1','type':'','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG7 end");
		}
	}

	/**
	 * onPost event jsondata title no value.
	 */
	@Test
	public final void onPostNG8() {
		System.out.println("onPostNG8 start");
		try {
			String json = "{'id':'1','type':'event','data':{'title':''}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG8 end");
		}
	}

	/**
	 * onPost event jsondata no title.
	 */
	@Test
	public final void onPostNG9() {
		System.out.println("onPostNG9 start");
		try {
			String json = "{'id':'1','type':'event','data':{'title1':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG9 end");
		}
	}
	
	/**
	 * onPost project jsondata title no value.
	 */
	@Test
	public final void onPostNG10() {
		System.out.println("onPostNG10 start");
		try {
			String json = "{'id':'1','type':'project','data':{'title':''}}";
			String authorization = "Basic xxxxxxxpostProjectxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG10 end");
		}
	}
	
	/**
	 * onPost project jsondata no title.
	 */
	@Test
	public final void onPostNG11() {
		System.out.println("onPostNG11 start");
		try {
			String json = "{'id':'1','type':'project','data':{'title1':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostProjectxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG11 end");
		}
	}
	
	/**
	 * onPost document jsondata title no value.
	 */
	@Test
	public final void onPostNG12() {
		System.out.println("onPostNG12 start");
		try {
			String json = "{'id':'1','type':'doucument','data':{'title':'','fulltext':'12345'}}";
			String authorization = "Basic xxxxxxxpostDocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG12 end");
		}
	}
	
	/**
	 * onPost document jsondata fulltext no value.
	 */
	@Test
	public final void onPostNG13() {
		System.out.println("onPostNG13 start");
		try {
			String json = "{'id':'1','type':'doucument','data':{'title':'XXX.レビュー','fulltext':''}}";
			String authorization = "Basic xxxxxxxpostDocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG13 end");
		}
	}
	
	/**
	 * onPost document jsondata fulltext and title no value.
	 */
	@Test
	public final void onPostNG14() {
		System.out.println("onPostNG14 start");
		try {
			String json = "{'id':'1','type':'doucument','data':{'title':'','fulltext':''}}";
			String authorization = "Basic xxxxxxxpostDocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG14 end");
		}
	}
	
	/**
	 * onPost document jsondata no title.
	 */
	@Test
	public final void onPostNG15() {
		System.out.println("onPostNG15 start");
		try {
			String json = "{'id':'1','type':'doucument','data':{'title1':'XXX.レビュー','fulltext':'12345'}}";
			String authorization = "Basic xxxxxxxpostDocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG15 end");
		}
	}
	
	/**
	 * onPost document jsondata no fulltext.
	 */
	@Test
	public final void onPostNG16() {
		System.out.println("onPostNG16 start");
		try {
			String json = "{'id':'1','type':'doucument','data':{'title':'XXX.レビュー','fulltext1':'1234'}}";
			String authorization = "Basic xxxxxxxpostDocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG16 end");
		}
	}
	
	/**
	 * onPost document jsondata no fulltext and title .
	 */
	@Test
	public final void onPostNG17() {
		System.out.println("onPostNG17 start");
		try {
			String json = "{'id':'1','type':'doucument','data':{'title1':'XXX.レビュー','fulltext1':'123214'}}";
			String authorization = "Basic xxxxxxxpostDocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG17 end");
		}
	}
	
	/**
	 * onPost comment jsondata title no value.
	 */
	@Test
	public final void onPostNG18() {
		System.out.println("onPostNG18 start");
		try {
			String json = "{'id':'1','type':'comment','data':{'body':''}}";
			String authorization = "Basic xxxxxxxpostcommentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG18 end");
		}
	}
	
	/**
	 * onPost comment jsondata no title.
	 */
	@Test
	public final void onPostNG19() {
		System.out.println("onPostNG19 start");
		try {
			String json = "{'id':'1','type':'comment','data':{'body1':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostcommentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG19 end");
		}
	}
	
	/**
	 * onPost json type not correct.
	 */
	@Test
	public final void onPostNG20() {
		System.out.println("onPostNG20 start");
		try {
			String json = "{'id':'1','type':'event1','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG20 end");
		}
	}

	/**
	 * onPost mock putRequest return false.
	 */
	@Test
	public final void onPostNG21() {
		System.out.println("onPostNG21 start");
		MockUp<TagGeneratorPost> mockup1 = new MockUp<TagGeneratorPost>() {
			@Mock
			public boolean putRequest(String type, String id, Object data, String authorization) throws Exception {
				return false;
			}
		};
		try {
			String json = "{'id':'1','type':'event','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), statusCode);
			mockup1.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG21 end");
		}
	}

	/**
	 * onPost mock onPostEvent return null.
	 */
	@Test
	public final void onPostNG22() {
		System.out.println("onPostNG22 start");
		MockUp<TagGeneratorPost> mockup1 = new MockUp<TagGeneratorPost>() {
			@Mock
			public JSONArray onPostEvent(JSONObject eventDataObject) throws Exception {
				return null;
			}
		};
		try {
			String json = "{'id':'1','type':'event','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
			mockup1.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG22 end");
		}
	}
	
	/**
	 * onPost mock onPostProject return null.
	 */
	@Test
	public final void onPostNG23() {
		System.out.println("onPostNG23 start");
		MockUp<TagGeneratorPost> mockup1 = new MockUp<TagGeneratorPost>() {
			@Mock
			public JSONArray onPostProject(JSONObject projectDataObject) throws Exception {
				return null;
			}
		};
		try {
			String json = "{'id':'1','type':'project','data':{'title':'XXX.レビュー'}}";
			String authorization = "Basic xxxxxxxpostprojectxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
			mockup1.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG23 end");
		}
	}
	
	/**
	 * onPost mock onPostDocument return null.
	 */
	@Test
	public final void onPostNG24() {
		System.out.println("onPostNG24 start");
		MockUp<TagGeneratorPost> mockup1 = new MockUp<TagGeneratorPost>() {
			@Mock
			public JSONArray onPostDocument(JSONObject documentDataObject) throws Exception {
				return null;
			}
		};
		try {
			String json = "{'id':'1','type':'document','data':{'title':'XXX.レビュー','fulltext':'123214'}}";
			String authorization = "Basic xxxxxxxpostdocumentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
			mockup1.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG24 end");
		}
	}
	
	/**
	 * onPost mock onPostComment return null.
	 */
	@Test
	public final void onPostNG25() {
		System.out.println("onPostNG25 start");
		MockUp<TagGeneratorPost> mockup1 = new MockUp<TagGeneratorPost>() {
			@Mock
			public JSONArray onPostComment(JSONObject commentDataObject) throws Exception {
				return null;
			}
		};
		try {
			String json = "{'id':'1','type':'comment','data':{'body':'123214'}}";
			String authorization = "Basic xxxxxxxpostcommentxxxxxx";
			int statusCode = tagGeneratorPost.onPost(authorization, json).getStatus();
			Assert.assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), statusCode);
			mockup1.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostNG25 end");
		}
	}
	
	/**
	 * onPostEvent.
	 */
	@Test
	public final void onPostEventOK() {
		System.out.println("onPostEventOK start");
		try {
			String json = "{'title':'XXX.レビュー'}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostEvent(dataObject);
			Assert.assertNotNull(jsonData);
			String expectString = "[{\"name\":\"eventtype\",\"value\":\"検討会\"}]";
			Assert.assertEquals(expectString, jsonData.toString());
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostEventOK end");
		}
	}

	/**
	 * onPostEvent mock getEventType return null.
	 */
	@Test
	public final void onPostEventNG1() {
		System.out.println("onPostEventNG1 start");

		MockUp<Category> mockup1 = new MockUp<Category>() {
			@Mock
			public String getEventType(String eventTitle) throws Exception {
				return null;
			}
		};
		try {
			String json = "{'title':'XXX'}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostEvent(dataObject);
			Assert.assertNull(jsonData);
			mockup1.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostEventNG1 end");
		}
	}

	/**
	 * onPostProject.
	 */
	@Test
	public final void onPostProjectOK() {
		System.out.println("onPostProjectOK start");
		try {
			String json = "{'title':'XXX.レビュー'}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostProject(dataObject);
			Assert.assertNotNull(jsonData);
			String expectString = "[{\"name\":\"projecttype\",\"value\":\"検討会\"}]";
			Assert.assertEquals(expectString, jsonData.toString());
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostProjectOK end");
		}
	}

	/**
	 * onPostProject mock getProjectType return null.
	 */
	@Test
	public final void onPostProjectNG1() {
		System.out.println("onPostProjectNG1 start");

		MockUp<Category> mockup1 = new MockUp<Category>() {
			@Mock
			public String getProjectType(String eventTitle) throws Exception {
				return null;
			}
		};
		try {
			String json = "{'title':'XXX'}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostProject(dataObject);
			Assert.assertNull(jsonData);
			mockup1.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostProjectNG1 end");
		}
	}

	/**
	 * onPostDocument.
	 */
	@Test
	public final void onPostDocumentOK() {
		System.out.println("onPostDocumentOK start");
		try {
			String json = "{'title':'XXX.定例会','fulltext':'Sheet1 吾輩は猫背である。。。 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890 １２３４５６７８９０ ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ ﾜｶﾞﾊｲﾊﾈｺｾﾞﾃﾞｱﾙ｡｡｡ Sheet2 Sheet3 '}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostDocument(dataObject);
			Assert.assertNotNull(jsonData);
			String expectString = "[{\"name\":\"contenttype\",\"value\":\"その他コンテンツ\"},{\"name\":\"filetype\",\"value\":\"その他フォーマット\"},{\"name\":\"keyword\",\"value\":\"Sheet\"}]";
			Assert.assertEquals(expectString, jsonData.toString());
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostDocumentOK end");
		}
	}

	/**
	 * onPostDocument mock getContentType return null.
	 */
	@Test
	public final void onPostDocumentNG1() {
		System.out.println("onPostDocumentNG1 start");

		MockUp<Category> mockup1 = new MockUp<Category>() {
			@Mock
			public String getContentType(String eventTitle) throws Exception {
				return null;
			}
		};
		MockUp<Category> mockup2 = new MockUp<Category>() {
			@Mock
			public String getFileType(String eventTitle) throws Exception {
				return "ABC";
			}
		};
		try {
			String json = "{'title':'XXX.定例会','fulltext':'Sheet1 ...'}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostDocument(dataObject);
			Assert.assertNull(jsonData);
			mockup1.tearDown();
			mockup2.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostDocumentNG1 end");
		}
	}

	/**
	 * onPostDocument mock getFileType return null.
	 */
	@Test
	public final void onPostDocumentNG2() {
		System.out.println("onPostDocumentNG2 start");
		MockUp<Category> mockup1 = new MockUp<Category>() {
			@Mock
			public String getContentType(String eventTitle) throws Exception {
				return "ABC";
			}
		};
		MockUp<Category> mockup2 = new MockUp<Category>() {
			@Mock
			public String getFileType(String eventTitle) throws Exception {
				return null;
			}
		};
		try {
			String json = "{'title':'XXX.定例会','fulltext':'Sheet1 ...'}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostDocument(dataObject);
			Assert.assertNull(jsonData);
			mockup1.tearDown();
			mockup2.tearDown();
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostDocumentNG2 end");
		}
	}

	/**
	 * onPostComment.
	 */
	@Test
	public final void onPostCommentOK() {
		System.out.println("onPostCommentOK start");
		try {
			String json = "{'body':'Sheet1 吾輩は猫背である。。。 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890 １２３４５６７８９０ ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ ﾜｶﾞﾊｲﾊﾈｺｾﾞﾃﾞｱﾙ｡｡｡ Sheet2 Sheet3 '}";
			JSONObject dataObject = JSONObject.fromObject(json);
			JSONArray jsonData = null;
			jsonData = tagGeneratorPost.onPostComment(dataObject);
			Assert.assertNotNull(jsonData);
			String expectString = "[{\"name\":\"keyword\",\"value\":\"Sheet\"}]";
			Assert.assertEquals(expectString, jsonData.toString());
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("onPostCommentOK end");
		}
	}

	/**
	 * putRequest.
	 */
	@Test
	public final void putRequestOK() {
		System.out.println("putRequestOK start");
		try {
			String type = "event";
			String id = "1";
			String authorization = "Basic xxxxxxxpostEventxxxxxx";
			String json = "{\"name\":\"eventtype\",\"value\":\"検討会\"}";
			JSONObject dataObject = JSONObject.fromObject(json);
			boolean result = tagGeneratorPost.putRequest(type, id, dataObject, authorization);
			Assert.assertTrue(result);
		} catch (Exception e) {
			System.out.println("Exception ： " + e);
		} finally {
			System.out.println("putRequestOK end");
		}
	}
}
